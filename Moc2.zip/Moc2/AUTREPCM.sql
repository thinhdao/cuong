﻿Create Database Moc2
use Moc2

CREATE TABLE AUTREPCM
(
       REPCM_NUM  CHAR(10)  NOT NULL,                          -- ƒŒƒ|[ƒgNO
       REPCM_NAME  CHAR(60)  NOT NULL,                         -- ƒŒƒ|[ƒg–¼Ì
       REPCM_JOBID  CHAR(05)  NOT NULL,                        -- ƒWƒ‡ƒu‚h‚c
       REPCM_PGM  CHAR(10)  NOT NULL,                          -- ƒŒƒ|[ƒgì¬ƒvƒƒOƒ‰ƒ€
       REPCM_TYPE  CHAR(02)  NOT NULL,                         -- ƒŒƒ|[ƒgƒ^ƒCƒv
       REPCM_PGTYP  CHAR(02)  NOT NULL,                        -- ƒŒƒ|[ƒg‚ÌŽ†ƒ^ƒCƒv
       REPCM_PGSTL  CHAR(01)  NOT NULL,                        -- ƒŒƒ|[ƒg‚ÌƒŒƒCƒAƒEƒg
       REPCM_PRNTP  CHAR(30)  NOT NULL,                        -- ê—pƒvƒŠƒ“ƒ^Žw’è
       REPCM_TYMD  CHAR(08)  NOT NULL,                         -- “o˜^“ú
															   -- —\”õ
       CONSTRAINT PK_REPCM PRIMARY KEY(REPCM_NUM)
);

insert AUTREPCM values('BC01',N'Báo cáo thông tin',N'CTID',N'VLID',N'LG',N'a',N'a',N'Máy in','16052017')
insert AUTREPCM values('BC02',N'Báo cáo thông tin',N'CTID',N'VLID',N'LG',N'b',N'b',N'Máy in','16052017')
insert AUTREPCM values('BC03',N'Báo cáo thông tin',N'CTID',N'VLID',N'LG',N'c',N'c',N'Máy in','16052017')
insert AUTREPCM values('BC04',N'Báo cáo thông tin',N'CTID',N'VLID',N'LG',N'a',N'a',N'Máy in','16052017')
insert AUTREPCM values('BC05',N'Báo cáo thông tin',N'CTID',N'VLID',N'LG',N'b',N'b',N'Máy in','16052017')