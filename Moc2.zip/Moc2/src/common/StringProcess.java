package common;

/**
 * StringProcess.java
 *
 * Version 1.0
 *
 * Date: May 18, 2017
 *
 * Copyright ThinhDM1
 *
 * Modification Logs: 
 * DATE				AUTHOR			DESCRIPTION
 * ----------------------------------------------------------------------- 
 * May 18, 2017 	HueTT8 			Create
 * 
 */

public class StringProcess {
	
	
	
	/**
	 * Check value input  C  D ?.
	 * @param s
	 * @return
	 */
	public static boolean isUpdateDelete(String s){
		String regex1="c";
		String regex2="C";
		String regex3="d";
		String regex4="D";
		if(s.matches(regex1)|| s.matches(regex2) || s.matches(regex3)|| s.matches(regex4)){
			return true;
		}else{
			return false;
		}
	}

	
	
	

}
