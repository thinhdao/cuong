package model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;

import model.bean.AutrepcmBEAN;
/**
 * AutrepcmDAO.java
 *
 * Date: May 19, 2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * May 19, 2017        	ThinhDM1          Create
 */
public class AutrepcmDAO {
	String url = "jdbc:sqlserver://localhost:1433;databaseName=Moc2";
	String userName = "sa";
//	String password = "Thinhminhdao";
	String password = "abc@12345";
	Connection connection;

	void connect() {
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			connection = DriverManager.getConnection(url, userName, password);
			System.out.println("Ket noi thanh cong");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Ket noi loi");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.out.println("Ket noi loi");
		}
	}

	public ArrayList<AutrepcmBEAN> getListAutrepcmBEAN() {
		connect();
		String sql=	"select * from AUTREPCM";
		ResultSet rs = null;
		try {
			Statement stmt = connection.createStatement();
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		ArrayList<AutrepcmBEAN> list = new ArrayList<AutrepcmBEAN>();
		AutrepcmBEAN autrepcpBEAN;
		try {
			while(rs.next()){
				autrepcpBEAN = new AutrepcmBEAN();
				autrepcpBEAN.setRepcm_Num(rs.getString("REPCM_NUM").trim());
				autrepcpBEAN.setRepcm_Name(rs.getString("REPCM_NAME").trim());
				autrepcpBEAN.setRepcm_Jobid(rs.getString("REPCM_JOBID").trim());
				autrepcpBEAN.setRepcm_Pgm(rs.getString("REPCM_PGM").trim());
				autrepcpBEAN.setRepcm_Type(rs.getString("REPCM_TYPE").trim());
				autrepcpBEAN.setRepcm_Pgtyp(rs.getString("REPCM_PGTYP").trim());
				autrepcpBEAN.setRepcm_Pgstl(rs.getString("REPCM_PGSTL").trim());
				autrepcpBEAN.setRepcm_Prntp(rs.getString("REPCM_PRNTP").trim());
				autrepcpBEAN.setRepcm_Tymd(rs.getString("REPCM_TYMD").trim());
				list.add(autrepcpBEAN);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public ArrayList<AutrepcmBEAN> getListAutrepcmBEAN(String repcm_Num, String repcm_Jobid, String repcm_Pgm,String repcm_Type) {
		String sql;
		connect();
		// kiểm tra các giá trị nhập vào rỗng thì hiển thị tất cả
		if (repcm_Num == "" && repcm_Jobid == "" && repcm_Pgm == "" && repcm_Type == "") {
			sql = "select * from AUTREPCM ";
		} else {

			// nếu một trong các trường khác rỗng thì sẽ hiển thị value tương
			// ứng với trường đó
			if (repcm_Num == "") {
				repcm_Num = null;
			}
			if (repcm_Jobid == "") {
				repcm_Jobid = null;
			}
			if (repcm_Pgm == "") {
				repcm_Pgm = null;
			}
			if (repcm_Type == "") {
				repcm_Type = null;
			}
			//sql = "select * from AUTREPCM where REPCM_NUM like N'%"+ repcm_Num + "%' or  REPCM_JOBID like N'" + repcm_Jobid + "' or REPCM_PGM like N'" + repcm_Pgm + "' or REPCM_TYPE like '" + repcm_Type + "'";
			sql = "select * from AUTREPCM where REPCM_NUM like ? or  REPCM_JOBID like ? or REPCM_PGM like ? or REPCM_TYPE like ?";
//			System.out.println(sql);
//			System.out.println(repcm_Type);
		}
		PreparedStatement pstmt;
		ResultSet rs = null;
		Statement stmt = null;
		try {
			 pstmt=connection.prepareStatement(sql);
			pstmt.setString(1, "%"+repcm_Num+"%");
			pstmt.setString(2, "%"+repcm_Jobid+"%");
			pstmt.setString(3, "%"+repcm_Pgm+"%");
			pstmt.setString(4, "%"+repcm_Type+"%");
			rs = pstmt.executeQuery();
			
		} catch (SQLException e) {
			try {
				throw new SQLException("Error occur: " + e.getMessage());
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

		ArrayList<AutrepcmBEAN> list = new ArrayList<AutrepcmBEAN>();
		AutrepcmBEAN autrepcmBEAN;
		try {
			while (rs.next()) {
				autrepcmBEAN = new AutrepcmBEAN();
				
				autrepcmBEAN.setRepcm_Num(rs.getString("REPCM_NUM").trim());
				autrepcmBEAN.setRepcm_Name(rs.getString("REPCM_NAME").trim());
				autrepcmBEAN.setRepcm_Jobid(rs.getString("REPCM_JOBID").trim());
				autrepcmBEAN.setRepcm_Pgm(rs.getString("REPCM_PGM").trim());
				autrepcmBEAN.setRepcm_Type(rs.getString("REPCM_TYPE").trim());
				autrepcmBEAN.setRepcm_Pgtyp(rs.getString("REPCM_PGTYP").trim());
				autrepcmBEAN.setRepcm_Pgstl(rs.getString("REPCM_PGSTL").trim());
				autrepcmBEAN.setRepcm_Prntp(rs.getString("REPCM_PRNTP").trim());
				autrepcmBEAN.setRepcm_Tymd(rs.getString("REPCM_TYMD").trim());
				list.add(autrepcmBEAN);
			}
		} catch (SQLException | ParseException e) {		
			try {
				throw new Exception("Error occur: " + e.getMessage());
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

		} 
		return list;
	}

	public void UpdateAutrepcm(String repcm_Num, String repcm_Name, String repcm_Jobid, String repcm_Pgm, String repcm_Type,
			String repcm_Pgtyp, String repcm_Pgstl, String repcm_Prntp, String repcm_Tymd) {
		PreparedStatement prtmm = null;
		try {
			String sqlQuery = "update autrepcm set REPCM_NAME=?,REPCM_JOBID=?,REPCM_PGM=?,REPCM_TYPE=?,REPCM_PGTYP=?,REPCM_PGSTL=?,REPCM_PRNTP=?,REPCM_TYMD=?"
					+ " where REPCM_NUM = ?;";

			prtmm = connection.prepareStatement(sqlQuery);
			// set code.

			prtmm.setString(1, "%"+repcm_Name+"%");
			prtmm.setString(2, "%"+repcm_Jobid+"%");
			prtmm.setString(3, "%"+repcm_Pgm+"%");
			prtmm.setString(4, "%"+repcm_Type+"%");
			prtmm.setString(5, "%"+repcm_Pgtyp+"%");
			prtmm.setString(6, "%"+repcm_Pgstl+"%");
			prtmm.setString(7, "%"+repcm_Prntp+"%");
			prtmm.setString(8, "%"+repcm_Tymd+"%");

			prtmm.setString(9, repcm_Num);

			prtmm.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally {
			try {
				prtmm.close();
			} catch (SQLException e) {
				/* ignored */
				e.printStackTrace();
				try {
					throw new SQLException();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
	}

	public void DeleteAutrepcm(String repcm_Num) throws SQLException {
		PreparedStatement prtmm = null;
		try {
			String sqlQuery = "delete FROM AUTREPCM where REPCM_NUM = ?";
			prtmm = connection.prepareStatement(sqlQuery);
			prtmm.setString(1, "%"+repcm_Num+"%");
			prtmm.executeUpdate();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		} finally { 
		}
		
	}

	
		
	
}
