package model.bo;

import java.sql.SQLException;
import java.util.ArrayList;

import model.bean.AutrepcmBEAN;
import model.dao.AutrepcmDAO;
/**
 * AutrepcmBO.java
 *
 * Date: May 19, 2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * May 19, 2017        	ThinhDM1          Create
 */
public class AutrepcmBO {
	AutrepcmDAO autrepcmDAO = new AutrepcmDAO();

	/**
	 * @return autrepcmDAO.getListAutrepcpBEAN();
	 */
	public ArrayList<AutrepcmBEAN> getListAutrepcmBEAN() {
		return autrepcmDAO.getListAutrepcmBEAN();
	}

	/**
	 * @param repcm_Num
	 * @param repcm_Jobid
	 * @param repcm_Pgm
	 * @param repcm_Type
	 * @return
	 */
	public ArrayList<AutrepcmBEAN> getListAutrepcmBEAN(String repcm_Num, String repcm_Jobid, String repcm_Pgm,
			String repcm_Type) {
		return autrepcmDAO.getListAutrepcmBEAN(repcm_Num, repcm_Jobid, repcm_Pgm, repcm_Type);
	}

	/**
	 * @param repcm_Num
	 * @param repcm_Name
	 * @param repcm_Jobid
	 * @param repcm_Pgm
	 * @param repcm_Type
	 * @param repcm_Pgtyp
	 * @param repcm_Pgstl
	 * @param repcm_Prntp
	 * @param repcm_Tymd
	 * @throws SQLException
	 */
	public void UpdateAutrepcm(String repcm_Num, String repcm_Name, String repcm_Jobid, String repcm_Pgm, String repcm_Type,
			String repcm_Pgtyp, String repcm_Pgstl, String repcm_Prntp, String repcm_Tymd) throws SQLException {

			autrepcmDAO.UpdateAutrepcm(repcm_Num, repcm_Name, repcm_Jobid, repcm_Pgm, repcm_Type, repcm_Pgtyp, repcm_Pgstl,
					repcm_Prntp, repcm_Tymd);
	}

	/**
	 * @param repcm_Num
	 * @throws SQLException
	 */
	public void DeleteAutrepcm(String repcm_Num) throws SQLException {
		// TODO Auto-generated method stub
		autrepcmDAO.DeleteAutrepcm(repcm_Num);
	}
}
