/*package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import common.StringProcess;
import form.UpdateAutrepcmForm;
import model.bean.AutrepcmBEAN;
import model.bo.AutrepcmBO;

public class UpdateAutrepcmAction extends Action {

	 (non-Javadoc)
	 * @see org.apache.struts.action.Action#execute(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
	 
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		UpdateAutrepcmForm updateAutrepcmForm = (UpdateAutrepcmForm) form;
		AutrepcmBO autrepcmBO = new AutrepcmBO();
		ArrayList<String> focus = new ArrayList<String>();
		
		if (updateAutrepcmForm.getSubmitUpdate() != null) {
			String[] updateChar = updateAutrepcmForm.getUpdateChar();
			String[] repcm_Num = updateAutrepcmForm.getRepcm_Num();
			String[] repcm_Name = updateAutrepcmForm.getRepcm_Name();
			String[] repcm_Jobid = updateAutrepcmForm.getRepcm_Jobid();
			String[] repcm_Pgm = updateAutrepcmForm.getRepcm_Pgm();
			String[] repcm_Type = updateAutrepcmForm.getRepcm_Type();
			String[] repcm_Pgtyp = updateAutrepcmForm.getRepcm_Pgtyp();
			String[] repcm_Pgstl = updateAutrepcmForm.getRepcm_Pgstl();
			String[] repcm_Prntp = updateAutrepcmForm.getRepcm_Prntp();
			String[] repcm_Tymd = updateAutrepcmForm.getRepcm_Tymd();

			// Variable check error item 26.
			int checkLoiItem26 = 0;
			int checkLoiItem36 = 0;
			int checkSchoolLoi = 0;

			for (int i = 0; i < updateChar.length; i++) {
				if (!updateChar[i].equals("")) {

					// Failure condition input item 26 C D
					if (StringProcess.isUpdateDelete(updateChar[i]) == true) {

						// if item 26 is C then continue valid
						if (updateChar[i].equals("c")|| updateChar[i].equals("C")) {
							if (checkSchoolLoi == 0 && checkLoiItem36 == 0) {
								// When check success then perform method
//								makerNameMasterBo.UpdateMakerNameMaster(repcm_Num[i],repcm_Name[i]);
								autrepcmBO.UpdateAutrepcm(repcm_Num[i], repcm_Name[i], repcm_Jobid[i], repcm_Pgm[i], repcm_Type[i], repcm_Pgtyp[i], repcm_Pgstl[i], repcm_Prntp[i], repcm_Tymd[i]);
							}

						} else if (updateChar[i].equals("d")|| updateChar[i].equals("D")) {
//								makerNameMasterBo.DeleteMakerNameMaster(manufactureCode1[i]);
							autrepcmBO.DeleteAutrepcm(repcm_Num[i]);
						}
					} else {
						checkLoiItem26++;
						focus.add("test1234" + String.valueOf(i + 1));

					}
				}
			}
		
		
			
		
		}

//		ArrayList<MakerNameMaster> listAfterUpdate = makerNameMasterBo.getListMakerNameMaster();
		ArrayList<AutrepcmBEAN> listAfterUpdate = autrepcmBO.getListAutrepcmBEAN();
//		danhSachMakerNameMasterForm.setListMakerNameMaster(listAfterUpdate);
		updateAutrepcmForm.setListAutrepcmBEAN(listAfterUpdate);

		return mapping.findForward("updateDe");
	}
	
}
*/