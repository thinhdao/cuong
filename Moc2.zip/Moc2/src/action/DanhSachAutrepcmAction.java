package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import common.StringProcess;
import form.DanhSachAutrepcmForm;
import model.bean.AutrepcmBEAN;
import model.bo.AutrepcmBO;
/**
 * DanhSachAutrepcmAction.java
 *
 * Date: May 19, 2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * May 19, 2017        	ThinhDM1          Create
 */
public class DanhSachAutrepcmAction extends Action {

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.struts.action.Action#execute(org.apache.struts.action.
	 * ActionMapping, org.apache.struts.action.ActionForm,
	 * javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse)
	 */
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		DanhSachAutrepcmForm danhSachAutrepcmForm = (DanhSachAutrepcmForm) form;
		
		AutrepcmBO autrepcmBO = new AutrepcmBO();
		
		// tạo các biến để lấy dl từ form
				String submit = danhSachAutrepcmForm.getSumit();
				String repcm_Num = danhSachAutrepcmForm.getRepcm_Num();
				String repcm_Jobid = danhSachAutrepcmForm.getRepcm_Jobid();
				String repcm_Pgm = danhSachAutrepcmForm.getRepcm_Pgm();
				String repcm_Type = danhSachAutrepcmForm.getRepcm_Type();
		
		ArrayList<String> focus = new ArrayList<String>();
		
		if (danhSachAutrepcmForm.getSubmitUpdate() != null) {
			String[] updateChar = danhSachAutrepcmForm.getUpdateChar();
			String[] repcm_Num1 = danhSachAutrepcmForm.getRepcm_Num1();
			String[] updaterepcm_Name = danhSachAutrepcmForm.getUpdaterepcm_Name();
			String[] updaterepcm_Jobid = danhSachAutrepcmForm.getUpdaterepcm_Jobid();
			String[] updaterepcm_Pgm = danhSachAutrepcmForm.getUpdaterepcm_Pgm();
			String[] updaterepcm_Type = danhSachAutrepcmForm.getUpdaterepcm_Type();
			String[] updaterepcm_Pgtyp = danhSachAutrepcmForm.getUpdaterepcm_Pgtyp();
			String[] updaterepcm_Pgstl = danhSachAutrepcmForm.getUpdaterepcm_Pgstl();
			String[] updaterepcm_Prntp = danhSachAutrepcmForm.getUpdaterepcm_Prntp();
			String[] updaterepcm_Tymd = danhSachAutrepcmForm.getUpdaterepcm_Tymd();

			// Variable check error item 26.
			int checkLoiItem26 = 0;
			int checkLoiItem36 = 0;
			int checkSchoolLoi = 0;
			System.out.println("1111111111111");
			for (int i = 0; i < updateChar.length; i++) {
				if (!updateChar[i].equals("")) {
					System.out.println("22222222222");
					// Failure condition input item  C D
					if (StringProcess.isUpdateDelete(updateChar[i]) == true) {
						System.out.println("333333333");
						// if item 26 is C then continue valid
						if (updateChar[i].equals("c")|| updateChar[i].equals("C")) {
							System.out.println("4444444");
							if (checkSchoolLoi == 0 && checkLoiItem36 == 0) {
								System.out.println("55555555");
								// When check success then perform method
//								makerNameMasterBo.UpdateMakerNameMaster(repcm_Num[i],repcm_Name[i]);
								autrepcmBO.UpdateAutrepcm(repcm_Num1[i], updaterepcm_Name[i], updaterepcm_Jobid[i], updaterepcm_Pgm[i], updaterepcm_Type[i], updaterepcm_Pgtyp[i], updaterepcm_Pgstl[i], updaterepcm_Prntp[i], updaterepcm_Tymd[i]);
							}
							System.out.println("666666");
						} else if (updateChar[i].equals("d")|| updateChar[i].equals("D")) {
							System.out.println("7777777");
//								makerNameMasterBo.DeleteMakerNameMaster(manufactureCode1[i]);
							autrepcmBO.DeleteAutrepcm(repcm_Num1[i]);
						}
					} else {
						checkLoiItem26++;
						focus.add("test1234" + String.valueOf(i + 1));
						System.out.println("ddddđ");
					}
				}
			}
		}
		
		ArrayList<AutrepcmBEAN> listAfterUpdate = autrepcmBO.getListAutrepcmBEAN();
		/**
		 * Lay danh sach Autrepcm
		 */
//		AutrepcmBO autrepcmBO = new AutrepcmBO();
//		ArrayList<AutrepcmBEAN> listAutrepcmBEAN ;
		
		
		
		// kiểm tra tất cả các giá trị nhập vào có rỗng k
		if (repcm_Num == null && repcm_Jobid == null && repcm_Pgm == null && repcm_Type == null) {
			listAfterUpdate=autrepcmBO.getListAutrepcmBEAN();
			} else
			if (repcm_Num == "" && repcm_Jobid == "" && repcm_Pgm == "" && repcm_Type == "") {
				listAfterUpdate=autrepcmBO.getListAutrepcmBEAN();
			} else {
//				System.out.println("hgfhqdfh");
				listAfterUpdate=autrepcmBO.getListAutrepcmBEAN(repcm_Num, repcm_Jobid, repcm_Pgm, repcm_Type);

			}
		
		
		danhSachAutrepcmForm.setListAutrepcpBEAN(listAfterUpdate);
		
		
		
		return mapping.findForward("dsAutrepcm");
	}

}
