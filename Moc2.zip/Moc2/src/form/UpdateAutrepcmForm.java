/*package form;

import java.util.ArrayList;

import org.apache.struts.action.ActionForm;

import model.bean.AutrepcmBEAN;

public class UpdateAutrepcmForm extends ActionForm{
	*//**
	 * 
	 *//*
	private static final long serialVersionUID = 1L;
	private String submitUpdate;
	private String[] updateChar;
	private String[] repcm_Name;
	private String[] repcm_Jobid;
	private String[] repcm_Pgm;
	private String[] repcm_Type;
	private String[] repcm_Pgtyp;
	private String[] repcm_Pgstl;
	private String[] repcm_Prntp;
	private String[] repcm_Tymd;
	private String[] repcm_Num;
	//private String[] manufactureCode1;
	private ArrayList<AutrepcmBEAN> listAutrepcmBEAN;
	*//**
	 * @return the submitUpdate
	 *//*
	public String getSubmitUpdate() {
		return submitUpdate;
	}
	*//**
	 * @param submitUpdate the submitUpdate to set
	 *//*
	public void setSubmitUpdate(String submitUpdate) {
		this.submitUpdate = submitUpdate;
	}
	*//**
	 * @return the updateChar
	 *//*
	public String[] getUpdateChar() {
		return updateChar;
	}
	*//**
	 * @param updateChar the updateChar to set
	 *//*
	public void setUpdateChar(String[] updateChar) {
		this.updateChar = updateChar;
	}
	*//**
	 * @return the repcm_Name
	 *//*
	public String[] getRepcm_Name() {
		return repcm_Name;
	}
	*//**
	 * @param repcm_Name the repcm_Name to set
	 *//*
	public void setRepcm_Name(String[] repcm_Name) {
		this.repcm_Name = repcm_Name;
	}
	*//**
	 * @return the repcm_Jobid
	 *//*
	public String[] getRepcm_Jobid() {
		return repcm_Jobid;
	}
	*//**
	 * @param repcm_Jobid the repcm_Jobid to set
	 *//*
	public void setRepcm_Jobid(String[] repcm_Jobid) {
		this.repcm_Jobid = repcm_Jobid;
	}
	*//**
	 * @return the repcm_Pgm
	 *//*
	public String[] getRepcm_Pgm() {
		return repcm_Pgm;
	}
	*//**
	 * @param repcm_Pgm the repcm_Pgm to set
	 *//*
	public void setRepcm_Pgm(String[] repcm_Pgm) {
		this.repcm_Pgm = repcm_Pgm;
	}
	*//**
	 * @return the repcm_Type
	 *//*
	public String[] getRepcm_Type() {
		return repcm_Type;
	}
	*//**
	 * @param repcm_Type the repcm_Type to set
	 *//*
	public void setRepcm_Type(String[] repcm_Type) {
		this.repcm_Type = repcm_Type;
	}
	*//**
	 * @return the repcm_Pgtyp
	 *//*
	public String[] getRepcm_Pgtyp() {
		return repcm_Pgtyp;
	}
	*//**
	 * @param repcm_Pgtyp the repcm_Pgtyp to set
	 *//*
	public void setRepcm_Pgtyp(String[] repcm_Pgtyp) {
		this.repcm_Pgtyp = repcm_Pgtyp;
	}
	*//**
	 * @return the repcm_Pgstl
	 *//*
	public String[] getRepcm_Pgstl() {
		return repcm_Pgstl;
	}
	*//**
	 * @param repcm_Pgstl the repcm_Pgstl to set
	 *//*
	public void setRepcm_Pgstl(String[] repcm_Pgstl) {
		this.repcm_Pgstl = repcm_Pgstl;
	}
	*//**
	 * @return the repcm_Prntp
	 *//*
	public String[] getRepcm_Prntp() {
		return repcm_Prntp;
	}
	*//**
	 * @param repcm_Prntp the repcm_Prntp to set
	 *//*
	public void setRepcm_Prntp(String[] repcm_Prntp) {
		this.repcm_Prntp = repcm_Prntp;
	}
	*//**
	 * @return the repcm_Tymd
	 *//*
	public String[] getRepcm_Tymd() {
		return repcm_Tymd;
	}
	*//**
	 * @param repcm_Tymd the repcm_Tymd to set
	 *//*
	public void setRepcm_Tymd(String[] repcm_Tymd) {
		this.repcm_Tymd = repcm_Tymd;
	}
	*//**
	 * @return the repcm_Num
	 *//*
	public String[] getRepcm_Num() {
		return repcm_Num;
	}
	*//**
	 * @param repcm_Num the repcm_Num to set
	 *//*
	public void setRepcm_Num(String[] repcm_Num) {
		this.repcm_Num = repcm_Num;
	}
	*//**
	 * @return the listAutrepcmBEAN
	 *//*
	public ArrayList<AutrepcmBEAN> getListAutrepcmBEAN() {
		return listAutrepcmBEAN;
	}
	*//**
	 * @param listAutrepcmBEAN the listAutrepcmBEAN to set
	 *//*
	public void setListAutrepcmBEAN(ArrayList<AutrepcmBEAN> listAutrepcmBEAN) {
		this.listAutrepcmBEAN = listAutrepcmBEAN;
	}
	*//**
	 * @param submitUpdate
	 * @param updateChar
	 * @param repcm_Name
	 * @param repcm_Jobid
	 * @param repcm_Pgm
	 * @param repcm_Type
	 * @param repcm_Pgtyp
	 * @param repcm_Pgstl
	 * @param repcm_Prntp
	 * @param repcm_Tymd
	 * @param repcm_Num
	 * @param listAutrepcmBEAN
	 *//*
	public UpdateAutrepcmForm(String submitUpdate, String[] updateChar, String[] repcm_Name, String[] repcm_Jobid,
			String[] repcm_Pgm, String[] repcm_Type, String[] repcm_Pgtyp, String[] repcm_Pgstl, String[] repcm_Prntp,
			String[] repcm_Tymd, String[] repcm_Num, ArrayList<AutrepcmBEAN> listAutrepcmBEAN) {
		super();
		this.submitUpdate = submitUpdate;
		this.updateChar = updateChar;
		this.repcm_Name = repcm_Name;
		this.repcm_Jobid = repcm_Jobid;
		this.repcm_Pgm = repcm_Pgm;
		this.repcm_Type = repcm_Type;
		this.repcm_Pgtyp = repcm_Pgtyp;
		this.repcm_Pgstl = repcm_Pgstl;
		this.repcm_Prntp = repcm_Prntp;
		this.repcm_Tymd = repcm_Tymd;
		this.repcm_Num = repcm_Num;
		this.listAutrepcmBEAN = listAutrepcmBEAN;
	}
	*//**
	 * 
	 *//*
	public UpdateAutrepcmForm() {
		super();
	}
	
	
}
*/