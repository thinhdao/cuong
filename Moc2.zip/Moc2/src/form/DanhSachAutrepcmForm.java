package form;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

import model.bean.AutrepcmBEAN;

/**
 * AutrepcmBO.java
 *
 * Date: May 19, 2017
 *
 * Copyright 
 *
 * Modification Logs:
 * DATE                 AUTHOR          DESCRIPTION
 * -----------------------------------------------------------------------
 * May 19, 2017        	ThinhDM1          Create
 */
public class DanhSachAutrepcmForm extends ActionForm{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String repcm_Num;
	private String repcm_Jobid;
	private String repcm_Pgm;
	private String repcm_Type;
	private String sumit;
	private String repcm_Pgstl;
	private String repcm_Pgtyp;
	private ArrayList<AutrepcmBEAN> listAutrepcmBEAN;
	private String submitUpdate;
	private String[] updateChar;
	private String[] updaterepcm_Name;
	private String[] updaterepcm_Jobid;
	private String[] updaterepcm_Pgm;
	private String[] updaterepcm_Type;
	private String[] updaterepcm_Pgtyp;
	private String[] updaterepcm_Pgstl;
	private String[] updaterepcm_Prntp;
	private String[] updaterepcm_Tymd;
	private String[] repcm_Num1;
	
	/**
	 * @return the repcm_Num1
	 */
	public String[] getRepcm_Num1() {
		return repcm_Num1;
	}

	/**
	 * @param repcm_Num1 the repcm_Num1 to set
	 */
	public void setRepcm_Num1(String[] repcm_Num1) {
		this.repcm_Num1 = repcm_Num1;
	}

	/**
	 * @return the submitUpdate
	 */
	public String getSubmitUpdate() {
		return submitUpdate;
	}

	/**
	 * @param submitUpdate the submitUpdate to set
	 */
	public void setSubmitUpdate(String submitUpdate) {
		this.submitUpdate = submitUpdate;
	}

	/**
	 * @return the updateChar
	 */
	public String[] getUpdateChar() {
		return updateChar;
	}

	/**
	 * @param updateChar the updateChar to set
	 */
	public void setUpdateChar(String[] updateChar) {
		this.updateChar = updateChar;
	}

	/**
	 * @return the updaterepcm_Name
	 */
	public String[] getUpdaterepcm_Name() {
		return updaterepcm_Name;
	}

	/**
	 * @param updaterepcm_Name the updaterepcm_Name to set
	 */
	public void setUpdaterepcm_Name(String[] updaterepcm_Name) {
		this.updaterepcm_Name = updaterepcm_Name;
	}

	/**
	 * @return the updaterepcm_Jobid
	 */
	public String[] getUpdaterepcm_Jobid() {
		return updaterepcm_Jobid;
	}

	/**
	 * @param updaterepcm_Jobid the updaterepcm_Jobid to set
	 */
	public void setUpdaterepcm_Jobid(String[] updaterepcm_Jobid) {
		this.updaterepcm_Jobid = updaterepcm_Jobid;
	}

	/**
	 * @return the updaterepcm_Pgm
	 */
	public String[] getUpdaterepcm_Pgm() {
		return updaterepcm_Pgm;
	}

	/**
	 * @param updaterepcm_Pgm the updaterepcm_Pgm to set
	 */
	public void setUpdaterepcm_Pgm(String[] updaterepcm_Pgm) {
		this.updaterepcm_Pgm = updaterepcm_Pgm;
	}

	/**
	 * @return the updaterepcm_Type
	 */
	public String[] getUpdaterepcm_Type() {
		return updaterepcm_Type;
	}

	/**
	 * @param updaterepcm_Type the updaterepcm_Type to set
	 */
	public void setUpdaterepcm_Type(String[] updaterepcm_Type) {
		this.updaterepcm_Type = updaterepcm_Type;
	}

	/**
	 * @return the updaterepcm_Pgtyp
	 */
	public String[] getUpdaterepcm_Pgtyp() {
		return updaterepcm_Pgtyp;
	}

	/**
	 * @param updaterepcm_Pgtyp the updaterepcm_Pgtyp to set
	 */
	public void setUpdaterepcm_Pgtyp(String[] updaterepcm_Pgtyp) {
		this.updaterepcm_Pgtyp = updaterepcm_Pgtyp;
	}

	/**
	 * @return the updaterepcm_Pgstl
	 */
	public String[] getUpdaterepcm_Pgstl() {
		return updaterepcm_Pgstl;
	}

	/**
	 * @param updaterepcm_Pgstl the updaterepcm_Pgstl to set
	 */
	public void setUpdaterepcm_Pgstl(String[] updaterepcm_Pgstl) {
		this.updaterepcm_Pgstl = updaterepcm_Pgstl;
	}

	/**
	 * @return the updaterepcm_Prntp
	 */
	public String[] getUpdaterepcm_Prntp() {
		return updaterepcm_Prntp;
	}

	/**
	 * @param updaterepcm_Prntp the updaterepcm_Prntp to set
	 */
	public void setUpdaterepcm_Prntp(String[] updaterepcm_Prntp) {
		this.updaterepcm_Prntp = updaterepcm_Prntp;
	}

	/**
	 * @return the updaterepcm_Tymd
	 */
	public String[] getUpdaterepcm_Tymd() {
		return updaterepcm_Tymd;
	}

	/**
	 * @param updaterepcm_Tymd the updaterepcm_Tymd to set
	 */
	public void setUpdaterepcm_Tymd(String[] updaterepcm_Tymd) {
		this.updaterepcm_Tymd = updaterepcm_Tymd;
	}

	

	/**
	 * @return the repcm_Pgtyp
	 */
	public String getRepcm_Pgtyp() {
		return repcm_Pgtyp;
	}

	/**
	 * @param repcm_Pgtyp the repcm_Pgtyp to set
	 */
	public void setRepcm_Pgtyp(String repcm_Pgtyp) {
		this.repcm_Pgtyp = repcm_Pgtyp;
	}

	/**
	 * @return the repcm_Pgstl
	 */
	public String getRepcm_Pgstl() {
		return repcm_Pgstl;
	}

	/**
	 * @param repcm_Pgstl the repcm_Pgstl to set
	 */
	public void setRepcm_Pgstl(String repcm_Pgstl) {
		this.repcm_Pgstl = repcm_Pgstl;
	}

	/**
	 * @param listAutrepcmBEAN the listAutrepcmBEAN to set
	 */
	public void setListAutrepcmBEAN(ArrayList<AutrepcmBEAN> listAutrepcmBEAN) {
		this.listAutrepcmBEAN = listAutrepcmBEAN;
	}

	/**
	 * @return the sumit
	 */
	public String getSumit() {
		return sumit;
	}

	/**
	 * @param sumit the sumit to set
	 */
	public void setSumit(String sumit) {
		this.sumit = sumit;
	}

	/**
	 * @return the repcm_Num
	 */
	public String getRepcm_Num() {
		return repcm_Num;
	}

	/**
	 * @param repcm_Num the repcm_Num to set
	 */
	public void setRepcm_Num(String repcm_Num) {
		this.repcm_Num = repcm_Num;
	}

	/**
	 * @return the repcm_Jobid
	 */
	public String getRepcm_Jobid() {
		return repcm_Jobid;
	}

	/**
	 * @param repcm_Jobid the repcm_Jobid to set
	 */
	public void setRepcm_Jobid(String repcm_Jobid) {
		this.repcm_Jobid = repcm_Jobid;
	}

	/**
	 * @return the repcm_Pgm
	 */
	public String getRepcm_Pgm() {
		return repcm_Pgm;
	}

	/**
	 * @param repcm_Pgm the repcm_Pgm to set
	 */
	public void setRepcm_Pgm(String repcm_Pgm) {
		this.repcm_Pgm = repcm_Pgm;
	}

	/**
	 * @return the repcm_Type
	 */
	public String getRepcm_Type() {
		return repcm_Type;
	}

	/**
	 * @param repcm_Type the repcm_Type to set
	 */
	public void setRepcm_Type(String repcm_Type) {
		this.repcm_Type = repcm_Type;
	}


	/**
	 * @return the serialversionuid
	 */
	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	

	/**
	 * @return the listAutrepcpBEAN
	 */
	public ArrayList<AutrepcmBEAN> getListAutrepcmBEAN() {
		return listAutrepcmBEAN;
	}

	/**
	 * @param listAutrepcmBEAN the listAutrepcmBEAN to set
	 */
	public void setListAutrepcpBEAN(ArrayList<AutrepcmBEAN> listAutrepcmBEAN) {
		this.listAutrepcmBEAN = listAutrepcmBEAN;
	}
	
	
		
	/**
	 * @param repcm_Num
	 * @param repcm_Jobid
	 * @param repcm_Pgm
	 * @param repcm_Type
	 * @param sumit
	 * @param repcm_Pgstl
	 * @param repcm_Pgtyp
	 * @param listAutrepcmBEAN
	 * @param submitUpdate
	 * @param updateChar
	 * @param updaterepcm_Name
	 * @param updaterepcm_Jobid
	 * @param updaterepcm_Pgm
	 * @param updaterepcm_Type
	 * @param updaterepcm_Pgtyp
	 * @param updaterepcm_Pgstl
	 * @param updaterepcm_Prntp
	 * @param updaterepcm_Tymd
	 * @param repcm_Num1
	 */
	public DanhSachAutrepcmForm(String repcm_Num, String repcm_Jobid, String repcm_Pgm, String repcm_Type, String sumit,
			String repcm_Pgstl, String repcm_Pgtyp, ArrayList<AutrepcmBEAN> listAutrepcmBEAN, String submitUpdate,
			String[] updateChar, String[] updaterepcm_Name, String[] updaterepcm_Jobid, String[] updaterepcm_Pgm,
			String[] updaterepcm_Type, String[] updaterepcm_Pgtyp, String[] updaterepcm_Pgstl,
			String[] updaterepcm_Prntp, String[] updaterepcm_Tymd, String[] repcm_Num1) {
		super();
		this.repcm_Num = repcm_Num;
		this.repcm_Jobid = repcm_Jobid;
		this.repcm_Pgm = repcm_Pgm;
		this.repcm_Type = repcm_Type;
		this.sumit = sumit;
		this.repcm_Pgstl = repcm_Pgstl;
		this.repcm_Pgtyp = repcm_Pgtyp;
		this.listAutrepcmBEAN = listAutrepcmBEAN;
		this.submitUpdate = submitUpdate;
		this.updateChar = updateChar;
		this.updaterepcm_Name = updaterepcm_Name;
		this.updaterepcm_Jobid = updaterepcm_Jobid;
		this.updaterepcm_Pgm = updaterepcm_Pgm;
		this.updaterepcm_Type = updaterepcm_Type;
		this.updaterepcm_Pgtyp = updaterepcm_Pgtyp;
		this.updaterepcm_Pgstl = updaterepcm_Pgstl;
		this.updaterepcm_Prntp = updaterepcm_Prntp;
		this.updaterepcm_Tymd = updaterepcm_Tymd;
		this.repcm_Num1 = repcm_Num1;
	}
	
	
	
	/**
	 * 
	 */
	public DanhSachAutrepcmForm() {
		super();
	}

	/**
	 * set UTF-8
	 * 
	 * @param mapping
	 * @param request
	 */
	@Override		
	public void reset(ActionMapping mapping, HttpServletRequest request) {
		try {
			request.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
